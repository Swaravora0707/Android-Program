package com.example.simpleinterestandcompoundinterest;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etPrincipal, etRate, etTime;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPrincipal = findViewById(R.id.etPrincipal);
        etRate = findViewById(R.id.etRate);
        etTime = findViewById(R.id.etTime);
        tvResult = findViewById(R.id.tvResult);
    }

    // Create Options Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Handle Menu Click
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        String pStr = etPrincipal.getText().toString();
        String rStr = etRate.getText().toString();
        String tStr = etTime.getText().toString();

        if (pStr.isEmpty() || rStr.isEmpty() || tStr.isEmpty()) {
            Toast.makeText(this, "Please enter all values", Toast.LENGTH_SHORT).show();
            return true;
        }

        double P = Double.parseDouble(pStr);
        double R = Double.parseDouble(rStr);
        double T = Double.parseDouble(tStr);

        if (item.getItemId() == R.id.simpleInterest) {

            double SI = (P * R * T) / 100;
            tvResult.setText("Simple Interest = " + SI);

            return true;

        } else if (item.getItemId() == R.id.compoundInterest) {

            double CI = P * Math.pow((1 + R / 100), T) - P;
            tvResult.setText("Compound Interest = " + CI);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
