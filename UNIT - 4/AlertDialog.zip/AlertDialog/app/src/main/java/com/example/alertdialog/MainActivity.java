package com.example.alertdialog;


import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnSimple, btnConfirm, btnList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSimple = findViewById(R.id.Simple);
        btnConfirm = findViewById(R.id.Confirm);
        btnList = findViewById(R.id.List);

        // Simple Dialog
        btnSimple.setOnClickListener(v -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Simple Dialog")
                    .setMessage("This is a simple alert dialog")
                    .setPositiveButton("OK", (dialog, which) ->
                            Toast.makeText(this, "OK Clicked", Toast.LENGTH_SHORT).show())
                    .show();
        });

        // Confirmation Dialog
        btnConfirm.setOnClickListener(v -> {
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Exit")
                    .setMessage("Are you sure?")
                    .setPositiveButton("Yes", (dialog, which) -> finish())
                    .setNegativeButton("No", (dialog, which) ->
                            Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show())
                    .show();
        });

        // List Dialog
        btnList.setOnClickListener(v -> {
            String[] items = {"Doctor", "Engineer", "Teacher", "Lawyer"};

            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Select Profession")
                    .setItems(items, (dialog, which) ->
                            Toast.makeText(this,
                                    "Selected: " + items[which],
                                    Toast.LENGTH_SHORT).show())
                    .show();
        });
    }
}