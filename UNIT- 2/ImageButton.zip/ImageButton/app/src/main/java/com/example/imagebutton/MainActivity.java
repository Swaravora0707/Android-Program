package com.example.imagebutton;



import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageButton imgButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgButton = findViewById(R.id.imgButton);

        imgButton.setOnClickListener(v ->
                Toast.makeText(MainActivity.this, "Image Button Clicked!", Toast.LENGTH_SHORT).show()
        );
    }
}