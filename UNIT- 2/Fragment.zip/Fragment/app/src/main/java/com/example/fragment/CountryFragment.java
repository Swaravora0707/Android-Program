package com.example.fragment;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.ListFragment;

public class CountryFragment extends ListFragment {

    String[] countries = {"India", "USA", "UK", "Canada"};

    OnCountrySelectedListener listener;

    public interface OnCountrySelectedListener {
        void onCountrySelected(String country);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (OnCountrySelectedListener) context;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        setListAdapter(new ArrayAdapter<>(getActivity(),
                android.R.layout.simple_list_item_1, countries));
    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        listener.onCountrySelected(countries[position]);
    }
}