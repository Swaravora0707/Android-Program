package com.example.fragment;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

public class FlagFragment extends Fragment {

    ImageView imageView;

    public FlagFragment() {
        super(R.layout.fragment_flag);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        imageView = view.findViewById(R.id.imageView);
    }

    public void updateFlag(String country) {
        switch (country) {
            case "India":
                imageView.setImageResource(R.drawable.india);
                break;
            case "USA":
                imageView.setImageResource(R.drawable.usa);
                break;
            case "UK":
                imageView.setImageResource(R.drawable.uk);
                break;
            case "Canada":
                imageView.setImageResource(R.drawable.canada);
                break;
        }
    }
}
