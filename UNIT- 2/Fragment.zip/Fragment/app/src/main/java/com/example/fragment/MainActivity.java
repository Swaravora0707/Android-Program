package com.example.fragment;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements CountryFragment.OnCountrySelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    public void onCountrySelected(String country) {
        FlagFragment flagFragment = (FlagFragment) getSupportFragmentManager()
                .findFragmentById(R.id.flagFragment);

        flagFragment.updateFlag(country);
    }
}