package com.example.checkbox;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    CheckBox cbJava, cbAndroid, cbPython;
    Button btnSubmit;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cbJava = findViewById(R.id.cbJava);
        cbAndroid = findViewById(R.id.cbAndroid);
        cbPython = findViewById(R.id.cbPython);
        btnSubmit = findViewById(R.id.btnSubmit);
        tvResult = findViewById(R.id.tvResult);

        btnSubmit.setOnClickListener(v -> {

            StringBuilder result = new StringBuilder("Selected: ");

            if (cbJava.isChecked()) {
                result.append("Java ");
            }
            if (cbAndroid.isChecked()) {
                result.append("Android ");
            }
            if (cbPython.isChecked()) {
                result.append("Python ");
            }

            if (result.toString().equals("Selected: ")) {
                tvResult.setText("No option selected");
            } else {
                tvResult.setText(result.toString());
            }
        });
    }
}