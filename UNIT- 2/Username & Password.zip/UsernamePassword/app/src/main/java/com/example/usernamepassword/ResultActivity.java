package com.example.usernamepassword;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    TextView tvUsername, tvPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvUsername = findViewById(R.id.tvUsername);
        tvPassword = findViewById(R.id.tvPassword);

        // Get data from intent
        String username = getIntent().getStringExtra("username");
        String password = getIntent().getStringExtra("password");

        tvUsername.setText("Username: " + username);
        tvPassword.setText("Password: " + password);
    }
}
