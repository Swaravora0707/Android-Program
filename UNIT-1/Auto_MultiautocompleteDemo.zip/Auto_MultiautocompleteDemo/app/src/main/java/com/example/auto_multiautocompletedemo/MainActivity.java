package com.example.auto_multiautocompletedemo;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView atv;
    MultiAutoCompleteTextView mtv;
    ArrayAdapter arrayAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String country[] = {"India", "Germany", "Russia", "USA"};

        atv = findViewById(R.id.autocomplete_tv);
        mtv = findViewById(R.id.multiautocomplete_tv);


        arrayAdapter = new ArrayAdapter(
                MainActivity.this,
                android.R.layout.simple_list_item_1,
                country
        );

        atv.setThreshold(2);
        atv.setAdapter(arrayAdapter);

        mtv.setThreshold(2);
        mtv.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
        mtv.setAdapter(arrayAdapter);
    }
}
