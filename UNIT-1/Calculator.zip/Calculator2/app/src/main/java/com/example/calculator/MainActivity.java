package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText display;
    double firstValue = 0;
    String operator = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);
    }

    // Numbers and dot
    public void onClick(View view) {
        Button button = (Button) view;
        display.append(button.getText().toString());
    }

    // Operators + - * /
    public void onOperator(View view) {
        Button button = (Button) view;
        firstValue = Double.parseDouble(display.getText().toString());
        operator = button.getText().toString();
        display.setText("");
    }

    // Equal =
    public void onEqual(View view) {
        double secondValue = Double.parseDouble(display.getText().toString());
        double result = 0;

        switch (operator) {
            case "+":
                result = firstValue + secondValue;
                break;
            case "-":
                result = firstValue - secondValue;
                break;
            case "*":
                result = firstValue * secondValue;
                break;
            case "/":
                if (secondValue != 0)
                    result = firstValue / secondValue;
                else {
                    display.setText("Error");
                    return;
                }
                break;
        }

        display.setText(String.valueOf(result));
    }

    // Clear
    public void onClear(View view) {
        display.setText("");
        firstValue = 0;
        operator = "";
    }

    // sin cos tan
    public void onTrig(View view) {
        Button button = (Button) view;
        double value = Double.parseDouble(display.getText().toString());
        double result = 0;

        switch (button.getText().toString()) {
            case "sin":
                result = Math.sin(Math.toRadians(value));
                break;
            case "cos":
                result = Math.cos(Math.toRadians(value));
                break;
            case "tan":
                result = Math.tan(Math.toRadians(value));
                break;
        }

        display.setText(String.valueOf(result));
    }
}