package com.example.radiogroupexample;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    ImageView img;
    RadioGroup rb;
    RadioButton rb1,rb2,rb3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = findViewById(R.id.img);

        rb = findViewById(R.id.rb);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);

        rb.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (rb1.isChecked())
                {
                   img.setImageResource(R.drawable.flag_of_india);
                }else if (rb2.isChecked())
                {
                    img.setImageResource(R.drawable.russia);
                }else if (rb3.isChecked())
                {
                    img.setImageResource(R.drawable.germany);
                }
            }
        });
    }
}