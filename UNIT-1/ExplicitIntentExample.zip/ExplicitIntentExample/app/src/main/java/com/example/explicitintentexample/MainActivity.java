package com.example.explicitintentexample;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText username,password;
    Button m_login,m_submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        m_login = findViewById(R.id.m_login);
        m_submit = findViewById(R.id.m_submit);

        m_login.setOnClickListener(v -> {
            String user = username.getText().toString();
            String Password = password.getText().toString();

            if (user.equals("Swara"))
            {
                Intent data = new Intent(MainActivity.this,dashboard.class);

                data.putExtra("Username",user);
                data.putExtra("Password",Password);
                startActivity(data);
            }
            else {
                Toast.makeText(this, "Wrong Username", Toast.LENGTH_SHORT).show();
            }

        });
    }
}