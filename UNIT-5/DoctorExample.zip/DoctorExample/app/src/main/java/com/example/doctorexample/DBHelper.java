package com.example.doctorexample;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "DoctorDB";
    public static final int DB_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE Doc_detail (" +
                "doc_id INTEGER PRIMARY KEY," +
                "firstname TEXT," +
                "lastname TEXT," +
                "mob TEXT," +
                "addrs TEXT," +
                "city TEXT," +
                "specialization TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Doc_detail");
        onCreate(db);
    }
}