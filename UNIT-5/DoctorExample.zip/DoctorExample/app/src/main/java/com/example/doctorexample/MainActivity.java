package com.example.doctorexample;



import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etId, etFname, etLname, etMobile, etAddress, etCity, etSpecial;
    Button btnSubmit;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etId = findViewById(R.id.etId);
        etFname = findViewById(R.id.etFname);
        etLname = findViewById(R.id.etLname);
        etMobile = findViewById(R.id.etMobile);
        etAddress = findViewById(R.id.etAddress);
        etCity = findViewById(R.id.etCity);
        etSpecial = findViewById(R.id.etSpecial);
        btnSubmit = findViewById(R.id.btnSubmit);

        dbHelper = new DBHelper(this);

        btnSubmit.setOnClickListener(v -> {
            SQLiteDatabase db = dbHelper.getWritableDatabase();

            ContentValues cv = new ContentValues();
            cv.put("doc_id", etId.getText().toString());
            cv.put("firstname", etFname.getText().toString());
            cv.put("lastname", etLname.getText().toString());
            cv.put("mob", etMobile.getText().toString());
            cv.put("addrs", etAddress.getText().toString());
            cv.put("city", etCity.getText().toString());
            cv.put("specialization", etSpecial.getText().toString());

            long result = db.insert("Doc_detail", null, cv);

            if (result != -1)
                Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        });
    }
}