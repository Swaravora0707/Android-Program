package com.example.doctorexample;



import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SearchActivity extends AppCompatActivity {

    EditText etSearchId;
    Button btnSearch;
    TextView tvResult;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        etSearchId = findViewById(R.id.etSearchId);
        btnSearch = findViewById(R.id.btnSearch);
        tvResult = findViewById(R.id.tvResult);

        dbHelper = new DBHelper(this);

        btnSearch.setOnClickListener(v -> {

            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.rawQuery(
                    "SELECT * FROM Doc_detail WHERE doc_id=?",
                    new String[]{etSearchId.getText().toString()}
            );

            if (cursor.moveToFirst()) {

                String data =
                        "ID: " + cursor.getString(0) + "\n" +
                                "Name: " + cursor.getString(1) + " " + cursor.getString(2) + "\n" +
                                "Mobile: " + cursor.getString(3) + "\n" +
                                "Address: " + cursor.getString(4) + "\n" +
                                "City: " + cursor.getString(5) + "\n" +
                                "Specialization: " + cursor.getString(6);

                tvResult.setText(data);

            } else {
                tvResult.setText("Doctor Not Found");
            }

            cursor.close();
        });
    }
}