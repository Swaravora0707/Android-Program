package com.example.audiomanager;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnIncrease = findViewById(R.id.btnIncrease);
        Button btnDecrease = findViewById(R.id.btnDecrease);
        Button btnSilent = findViewById(R.id.btnSilent);
        Button btnNormal = findViewById(R.id.btnNormal);

        // Initialize AudioManager
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);

        // Increase Volume
        btnIncrease.setOnClickListener(v -> {
            audioManager.adjustVolume(AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            Toast.makeText(this, "Volume Increased", Toast.LENGTH_SHORT).show();
        });

        // Decrease Volume
        btnDecrease.setOnClickListener(v -> {
            audioManager.adjustVolume(AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
            Toast.makeText(this, "Volume Decreased", Toast.LENGTH_SHORT).show();
        });

        // Silent Mode
        btnSilent.setOnClickListener(v -> {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            Toast.makeText(this, "Silent Mode Activated", Toast.LENGTH_SHORT).show();
        });

        // Normal Mode
        btnNormal.setOnClickListener(v -> {
            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            Toast.makeText(this, "Normal Mode Activated", Toast.LENGTH_SHORT).show();
        });
    }
}
