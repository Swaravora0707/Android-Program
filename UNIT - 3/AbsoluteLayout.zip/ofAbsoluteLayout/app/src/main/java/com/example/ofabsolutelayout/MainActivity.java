package com.example.ofabsolutelayout;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button b = findViewById(R.id.abs_btn);
        b.setOnClickListener(v ->
                Toast.makeText(this, "AbsoluteLayout button", Toast.LENGTH_SHORT).show());
    }
}
