package com.example.edittextdemo;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText url = findViewById(R.id.url);
        TextView out = findViewById(R.id.out);
        Button show = findViewById(R.id.show);
        show.setOnClickListener(v -> out.setText(url.getText().toString().trim()));
    }
}
